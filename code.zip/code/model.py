import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image, ImageFile
import os
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix
import cv2

# Prevent PIL from failing on corrupt images
ImageFile.LOAD_TRUNCATED_IMAGES = True

# Step 1: Print environment setup
print("Step 1: Setting up environment")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")
print(f"PyTorch version: {torch.__version__}")

# Step 2: Define custom dataset class with corruption handling
print("\nStep 2: Defining Custom Dataset with Corruption Handling")
class RealFakeDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.classes = ['fake', 'real']
        self.images = []
        self.labels = []
        
        for label in self.classes:
            class_path = os.path.join(root_dir, label)
            label_idx = self.classes.index(label)
            for img_name in os.listdir(class_path):
                img_path = os.path.join(class_path, img_name)
                # Verify image before adding
                if self._is_valid_image(img_path):
                    self.images.append(img_path)
                    self.labels.append(label_idx)
                else:
                    print(f"Skipping corrupt image: {img_path}")
        
        print(f"Total valid images found: {len(self.images)}")
                
    def _is_valid_image(self, img_path):
        try:
            # Attempt to open and verify the image
            with Image.open(img_path) as img:
                img.verify()  # Verify image integrity
            # Re-open to check if it can be converted to RGB
            with Image.open(img_path) as img:
                img.convert('RGB')
            return True
        except (IOError, SyntaxError, ValueError) as e:
            return False
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        try:
            image = Image.open(img_path).convert('RGB')
            
            if self.transform:
                image = self.transform(image)
                
            return image, label
        except (IOError, OSError) as e:
            print(f"Error loading image {img_path}: {e}")
            # Return a replacement or skip this image
            # Option 1: Return a black image of the right size
            if self.transform:
                dummy = torch.zeros(3, 224, 224)
                return dummy, label
            # Option 2: Return a neighboring valid image
            return self.__getitem__((idx + 1) % len(self))

# Step 3: Define data transformations
print("\nStep 3: Defining Data Transformations")
train_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(10),
    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                        std=[0.229, 0.224, 0.225])
])

val_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                        std=[0.229, 0.224, 0.225])
])

# Step 4: Load datasets
print("\nStep 4: Loading Datasets")
base_path = "/home/vu-lab03-pc40/dl/realandfake_split"
train_dataset = RealFakeDataset(os.path.join(base_path, "train"), transform=train_transforms)
test_dataset = RealFakeDataset(os.path.join(base_path, "test"), transform=val_transforms)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True, num_workers=4)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False, num_workers=4)
print(f"Training samples: {len(train_dataset)}")
print(f"Testing samples: {len(test_dataset)}")

# Step 5: Define the model
print("\nStep 5: Defining Model Architecture")
class RealFakeDetector(nn.Module):
    def __init__(self):
        super(RealFakeDetector, self).__init__()
        self.backbone = models.resnet50(pretrained=True)
        
        for param in self.backbone.parameters():
            param.requires_grad = False
        
        num_features = self.backbone.fc.in_features
        self.backbone.fc = nn.Sequential(
            nn.Linear(num_features, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 2)
        )
        
    def forward(self, x):
        return self.backbone(x)

model = RealFakeDetector().to(device)
print("Model moved to GPU")

# Step 6: Define loss function and optimizer
print("\nStep 6: Defining Loss and Optimizer")
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-4)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=3)

# Step 7: Training function
print("\nStep 7: Defining Training Function")
def train_model(model, train_loader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    all_preds = []
    all_labels = []
    
    for i, (images, labels) in enumerate(train_loader):
        images, labels = images.to(device), labels.to(device)
        
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()
        _, preds = torch.max(outputs, 1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())
        
        if i % 10 == 0:
            print(f"Batch {i}/{len(train_loader)}, Loss: {loss.item():.4f}")
    
    epoch_loss = running_loss / len(train_loader)
    epoch_acc = accuracy_score(all_labels, all_preds)
    return epoch_loss, epoch_acc

# Step 8: Validation function
print("\nStep 8: Defining Validation Function")
def validate_model(model, test_loader, criterion, device):
    model.eval()
    running_loss = 0.0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            
            running_loss += loss.item()
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    epoch_loss = running_loss / len(test_loader)
    epoch_acc = accuracy_score(all_labels, all_preds)
    return epoch_loss, epoch_acc

# Step 9: Training loop
print("\nStep 9: Starting Training")
num_epochs = 20
best_acc = 0.0

for epoch in range(num_epochs):
    print(f"\nEpoch {epoch+1}/{num_epochs}")
    train_loss, train_acc = train_model(model, train_loader, criterion, optimizer, device)
    val_loss, val_acc = validate_model(model, test_loader, criterion, device)
    
    print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}")
    print(f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}")
    
    scheduler.step(val_loss)
    
    if val_acc > best_acc:
        best_acc = val_acc
        torch.save(model.state_dict(), 'best_realfake_model.pth')
        print("Saved best model")

# Step 10: Real-time detection function
print("\nStep 10: Defining Real-time Detection Function")
def realtime_detection():
    model.load_state_dict(torch.load('best_realfake_model.pth'))
    model.eval()
    
    cap = cv2.VideoCapture(0)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)
        
        for (x, y, w, h) in faces:
            face = frame[y:y+h, x:x+w]
            face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
            try:
                face = Image.fromarray(face)
                face = val_transforms(face).unsqueeze(0).to(device)
                
                with torch.no_grad():
                    output = model(face)
                    _, pred = torch.max(output, 1)
                    label = 'Real' if pred.item() == 1 else 'Fake'
                    
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            except Exception as e:
                print(f"Error processing frame: {str(e)}")
                continue
        
        cv2.imshow('Real/Fake Detection', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()

print("\nTraining complete! You can use realtime_detection() for camera inference")