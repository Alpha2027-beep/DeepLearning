import os
import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
import random
from tqdm import tqdm
import warnings
import torch.nn.functional as F
import timm
from torchvision.transforms.functional import to_tensor, normalize
from torch.optim.lr_scheduler import CosineAnnealingLR
import torchvision.transforms.functional as TF

warnings.filterwarnings('ignore')

# Set random seeds for reproducibility
def seed_everything(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed_everything()

# Configuration
class Config:
    DATA_ROOT = '/home/vu-lab03-pc40/dl/realandfake_split'
    IMG_SIZE = 224
    BATCH_SIZE = 32
    NUM_WORKERS = 4
    EPOCHS = 30
    LR = 0.0001
    DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    SEED = 42
    MODEL_PATH = 'best_fake_detection_model.pth'
    ENSEMBLE_MODEL_PATH = 'best_ensemble_model.pth'
    
config = Config()

# Custom Dataset for Real and Fake Images
class FaceForensicsDataset(Dataset):
    def __init__(self, root_dir, split='train', transform=None):
        self.root_dir = os.path.join(root_dir, split)
        self.real_dir = os.path.join(self.root_dir, 'real')
        self.fake_dir = os.path.join(self.root_dir, 'fake')
        self.transform = transform
        
        # Get all valid image files
        self.real_images = self._get_valid_images(self.real_dir)
        self.fake_images = self._get_valid_images(self.fake_dir)
        
        self.all_images = []
        for img_path in self.real_images:
            self.all_images.append((img_path, 0))  # 0 = real
        for img_path in self.fake_images:
            self.all_images.append((img_path, 1))  # 1 = fake
            
        print(f"Loaded {len(self.real_images)} real and {len(self.fake_images)} fake images for {split}")
    
    def _get_valid_images(self, directory):
        """Get valid image files, filtering out corrupted ones."""
        valid_images = []
        for filename in os.listdir(directory):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                file_path = os.path.join(directory, filename)
                try:
                    # Try opening the image to check if it's valid
                    img = Image.open(file_path)
                    img.verify()  # Verify it's an image
                    valid_images.append(file_path)
                except (IOError, SyntaxError) as e:
                    print(f"Skipping corrupted image {file_path}: {e}")
        return valid_images
    
    def __len__(self):
        return len(self.all_images)
    
    def __getitem__(self, idx):
        img_path, label = self.all_images[idx]
        
        try:
            image = Image.open(img_path).convert('RGB')
            
            if self.transform:
                image = self.transform(image)
                
            return image, label
        except Exception as e:
            print(f"Error loading image {img_path}: {e}")
            # Return a placeholder in case of error
            random_idx = random.randint(0, len(self.all_images) - 1)
            return self.__getitem__(random_idx)

# Data augmentation and transformations
def get_transforms(mode='train'):
    if mode == 'train':
        return transforms.Compose([
            transforms.Resize((config.IMG_SIZE, config.IMG_SIZE)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(10),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    else:
        return transforms.Compose([
            transforms.Resize((config.IMG_SIZE, config.IMG_SIZE)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

# Create data loaders
def create_dataloaders():
    train_dataset = FaceForensicsDataset(
        root_dir=config.DATA_ROOT,
        split='train',
        transform=get_transforms('train')
    )
    
    val_dataset = FaceForensicsDataset(
        root_dir=config.DATA_ROOT,
        split='val',
        transform=get_transforms('val')
    )
    
    test_dataset = FaceForensicsDataset(
        root_dir=config.DATA_ROOT,
        split='test',
        transform=get_transforms('test')
    )
    
    train_loader = DataLoader(
        train_dataset, 
        batch_size=config.BATCH_SIZE,
        shuffle=True,
        num_workers=config.NUM_WORKERS,
        pin_memory=True,
        drop_last=True
    )
    
    val_loader = DataLoader(
        val_dataset, 
        batch_size=config.BATCH_SIZE,
        shuffle=False,
        num_workers=config.NUM_WORKERS,
        pin_memory=True
    )
    
    test_loader = DataLoader(
        test_dataset, 
        batch_size=config.BATCH_SIZE,
        shuffle=False,
        num_workers=config.NUM_WORKERS,
        pin_memory=True
    )
    
    return train_loader, val_loader, test_loader

# Spatial Attention Module
class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        # Compute spatial attention 
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x_cat = torch.cat([avg_out, max_out], dim=1)
        x_out = self.conv(x_cat)
        
        # Apply attention
        return self.sigmoid(x_out) * x

# Channel Attention Module
class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // reduction_ratio, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_channels // reduction_ratio, in_channels, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out) * x

# Frequency Domain Analysis Layer
class FrequencyDomainAnalysis(nn.Module):
    def __init__(self, in_channels):
        super(FrequencyDomainAnalysis, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        
    def forward(self, x):
        # Convert to frequency domain using 2D FFT
        x_freq = torch.fft.fft2(x.float())
        x_freq_abs = torch.abs(x_freq)
        
        # Apply learnable filters in frequency domain
        x_freq_processed = self.conv1(x_freq_abs.real)
        
        # Combine with original features
        return x + self.conv2(x_freq_processed)

# EfficientNet Model with Special Attention to Facial Features
class EfficientNetFakeDetector(nn.Module):
    def __init__(self, pretrained=True):
        super(EfficientNetFakeDetector, self).__init__()
        self.model = timm.create_model('efficientnet_b0', pretrained=pretrained)
        
        # Replace classifier
        in_features = self.model.classifier.in_features
        self.model.classifier = nn.Identity()
        
        # Add spatial and channel attention modules
        self.channel_attention = ChannelAttention(in_features)
        self.spatial_attention = SpatialAttention()
        
        # Add frequency domain analysis
        self.freq_analysis = FrequencyDomainAnalysis(in_features)
        
        # Separate pathways for different facial features
        self.eyes_pathway = nn.Sequential(
            nn.Linear(in_features, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 64)
        )
        
        self.skin_pathway = nn.Sequential(
            nn.Linear(in_features, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 64)
        )
        
        self.structure_pathway = nn.Sequential(
            nn.Linear(in_features, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 64)
        )
        
        # Final classifier after concatenation of pathways
        self.classifier = nn.Sequential(
            nn.Linear(in_features + 64*3, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 1)
        )
        
    def forward(self, x):
        # Extract base features
        features = self.model(x)
        
        # Reshape for attention mechanisms
        features_2d = features.unsqueeze(-1).unsqueeze(-1)
        
        # Apply attention
        ca_features = self.channel_attention(features_2d)
        ca_features = ca_features.squeeze(-1).squeeze(-1)
        
        # Apply frequency domain analysis
        freq_features = self.freq_analysis(features_2d)
        freq_features = freq_features.squeeze(-1).squeeze(-1)
        
        # Specialized facial feature pathways
        eyes_features = self.eyes_pathway(features)
        skin_features = self.skin_pathway(features)
        structure_features = self.structure_pathway(features)
        
        # Concatenate all features
        combined_features = torch.cat([freq_features, eyes_features, skin_features, structure_features], dim=1)
        
        # Final classification
        output = self.classifier(combined_features)
        return output

# ResNet-based Model with DCT Focus
class ResNetDCTDetector(nn.Module):
    def __init__(self, pretrained=True):
        super(ResNetDCTDetector, self).__init__()
        self.model = models.resnet50(pretrained=pretrained)
        
        # Replace final classifier
        in_features = self.model.fc.in_features
        self.model.fc = nn.Identity()
        
        # DCT-focused layers
        self.dct_analysis = nn.Sequential(
            nn.Linear(in_features, 512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 256)
        )
        
        # Texture analysis layers
        self.texture_analysis = nn.Sequential(
            nn.Linear(in_features, 512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 256)
        )
        
        # Final classifier
        self.classifier = nn.Sequential(
            nn.Linear(256 + 256, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, 1)
        )
        
    def forward(self, x):
        # Extract features from ResNet
        features = self.model(x)
        
        # Apply DCT analysis and texture analysis
        dct_features = self.dct_analysis(features)
        texture_features = self.texture_analysis(features)
        
        # Concatenate features
        combined_features = torch.cat([dct_features, texture_features], dim=1)
        
        # Final classification
        output = self.classifier(combined_features)
        return output

# Ensemble Model
class EnsembleModel(nn.Module):
    def __init__(self, model1, model2):
        super(EnsembleModel, self).__init__()
        self.model1 = model1
        self.model2 = model2
        
        # Weighting layer
        self.weight_layer = nn.Linear(2, 1)
        
    def forward(self, x):
        # Get predictions from both models
        pred1 = torch.sigmoid(self.model1(x))
        pred2 = torch.sigmoid(self.model2(x))
        
        # Combine predictions
        combined = torch.cat([pred1, pred2], dim=1)
        weighted = self.weight_layer(combined)
        
        return weighted

# Training function
def train_model(model, train_loader, val_loader, criterion, optimizer, scheduler, num_epochs=config.EPOCHS):
    best_val_auc = 0.0
    best_model_weights = None
    
    for epoch in range(num_epochs):
        print(f'Epoch {epoch+1}/{num_epochs}')
        print('-' * 10)
        
        # Training phase
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0
        
        for inputs, labels in tqdm(train_loader):
            inputs = inputs.to(config.DEVICE)
            labels = labels.float().to(config.DEVICE).unsqueeze(1)
            
            # Zero the parameter gradients
            optimizer.zero_grad()
            
            # Forward
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            
            # Backward + optimize
            loss.backward()
            optimizer.step()
            
            # Statistics
            running_loss += loss.item() * inputs.size(0)
            predicted = (torch.sigmoid(outputs) > 0.5).float()
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
        
        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_acc = correct / total
        
        print(f'Train Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')
        
        # Validation phase
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0
        val_preds = []
        val_targets = []
        
        with torch.no_grad():
            for inputs, labels in tqdm(val_loader):
                inputs = inputs.to(config.DEVICE)
                labels = labels.float().to(config.DEVICE).unsqueeze(1)
                
                # Forward
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                
                # Statistics
                val_loss += loss.item() * inputs.size(0)
                predicted = (torch.sigmoid(outputs) > 0.5).float()
                val_total += labels.size(0)
                val_correct += (predicted == labels).sum().item()
                
                # Store predictions and targets for ROC calculation
                val_preds.extend(torch.sigmoid(outputs).cpu().numpy())
                val_targets.extend(labels.cpu().numpy())
        
        val_loss = val_loss / len(val_loader.dataset)
        val_acc = val_correct / val_total
        
        # Calculate ROC AUC
        fpr, tpr, _ = roc_curve(np.array(val_targets), np.array(val_preds))
        val_auc = auc(fpr, tpr)
        
        print(f'Val Loss: {val_loss:.4f} Acc: {val_acc:.4f} AUC: {val_auc:.4f}')
        
        # Update learning rate
        scheduler.step()
        
        # Save best model
        if val_auc > best_val_auc:
            best_val_auc = val_auc
            best_model_weights = model.state_dict().copy()
            print(f'New best model with AUC: {val_auc:.4f}')
    
    # Load best model weights
    model.load_state_dict(best_model_weights)
    return model

# Evaluate model
def evaluate_model(model, test_loader):
    model.eval()
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for inputs, labels in tqdm(test_loader):
            inputs = inputs.to(config.DEVICE)
            outputs = model(inputs)
            probs = torch.sigmoid(outputs).squeeze().cpu().numpy()
            
            all_preds.extend(probs)
            all_labels.extend(labels.numpy())
    
    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)
    
    # Calculate binary predictions
    binary_preds = (all_preds > 0.5).astype(int)
    
    # Print classification report
    print("\nClassification Report:")
    print(classification_report(all_labels, binary_preds, target_names=['Real', 'Fake']))
    
    # Calculate and plot ROC curve
    fpr, tpr, _ = roc_curve(all_labels, all_preds)
    roc_auc = auc(fpr, tpr)
    
    plt.figure(figsize=(10, 8))
    plt.plot(fpr, tpr, color='darkorange', lw=2, 
             label=f'ROC curve (AUC = {roc_auc:.3f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")
    plt.savefig('roc_curve.png')
    plt.close()
    
    # Plot confusion matrix
    cm = confusion_matrix(all_labels, binary_preds)
    plt.figure(figsize=(8, 6))
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Confusion Matrix')
    plt.colorbar()
    
    classes = ['Real', 'Fake']
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes)
    plt.yticks(tick_marks, classes)
    
    # Add text annotations
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(j, i, format(cm[i, j], 'd'),
                     ha="center", va="center",
                     color="white" if cm[i, j] > thresh else "black")
    
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    plt.savefig('confusion_matrix.png')
    plt.close()
    
    return roc_auc

# Function to visualize model attention
def visualize_attention(model, test_loader, num_samples=5):
    model.eval()
    samples_seen = 0
    fig, axes = plt.subplots(num_samples, 3, figsize=(15, 5*num_samples))
    
    for inputs, labels in test_loader:
        for i in range(inputs.size(0)):
            if samples_seen >= num_samples:
                break
                
            img = inputs[i].unsqueeze(0).to(config.DEVICE)
            label = labels[i].item()
            
            # Forward pass
            with torch.no_grad():
                _ = model(img)
                
            # Get original image
            orig_img = inputs[i].permute(1, 2, 0).cpu().numpy()
            orig_img = (orig_img * np.array([0.229, 0.224, 0.225])) + np.array([0.485, 0.456, 0.406])
            orig_img = np.clip(orig_img, 0, 1)
            
            # Display original image
            axes[samples_seen, 0].imshow(orig_img)
            axes[samples_seen, 0].set_title(f"{'Fake' if label == 1 else 'Real'} Face")
            axes[samples_seen, 0].axis('off')
            
            # Get spatial attention map (this would be specific to the implemented model)
            # This is a placeholder - you'll need to modify based on your actual model architecture
            if hasattr(model, 'spatial_attention'):
                # For EfficientNet model
                features = model.model(img)
                features_2d = features.unsqueeze(-1).unsqueeze(-1)
                attention_map = model.spatial_attention(features_2d)
                attention_map = attention_map.squeeze().cpu().numpy()
                
                # Resize attention map to match image size
                attention_map = cv2.resize(attention_map, (config.IMG_SIZE, config.IMG_SIZE))
                
                # Plot attention map
                axes[samples_seen, 1].imshow(attention_map, cmap='jet')
                axes[samples_seen, 1].set_title('Attention Map')
                axes[samples_seen, 1].axis('off')
                
                # Apply attention map as overlay
                heatmap = cv2.applyColorMap(np.uint8(255 * attention_map), cv2.COLORMAP_JET)
                heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB) / 255.0
                overlay = 0.7 * orig_img + 0.3 * heatmap
                
                axes[samples_seen, 2].imshow(overlay)
                axes[samples_seen, 2].set_title('Attention Overlay')
                axes[samples_seen, 2].axis('off')
            
            samples_seen += 1
            if samples_seen >= num_samples:
                break
                
        if samples_seen >= num_samples:
            break
    
    plt.tight_layout()
    plt.savefig('attention_visualization.png')
    plt.close()

# Main function to run the entire pipeline
def main():
    print(f"Using device: {config.DEVICE}")
    
    # Create data loaders
    train_loader, val_loader, test_loader = create_dataloaders()
    
    # Initialize models
    print("Initializing EfficientNet model...")
    efficientnet_model = EfficientNetFakeDetector(pretrained=True).to(config.DEVICE)
    
    print("Initializing ResNet model...")
    resnet_model = ResNetDCTDetector(pretrained=True).to(config.DEVICE)
    
    # Define loss function and optimizers
    criterion = nn.BCEWithLogitsLoss()
    
    optimizer_effnet = optim.AdamW(efficientnet_model.parameters(), lr=config.LR, weight_decay=1e-4)
    scheduler_effnet = CosineAnnealingLR(optimizer_effnet, T_max=config.EPOCHS)
    
    optimizer_resnet = optim.AdamW(resnet_model.parameters(), lr=config.LR, weight_decay=1e-4)
    scheduler_resnet = CosineAnnealingLR(optimizer_resnet, T_max=config.EPOCHS)
    
    # Train EfficientNet model
    print("Training EfficientNet model...")
    efficientnet_model = train_model(
        efficientnet_model,
        train_loader,
        val_loader,
        criterion,
        optimizer_effnet,
        scheduler_effnet,
        num_epochs=config.EPOCHS
    )
    
    # Save EfficientNet model
    torch.save(efficientnet_model.state_dict(), 'efficientnet_fake_detector.pth')
    
    # Train ResNet model
    print("Training ResNet model...")
    resnet_model = train_model(
        resnet_model,
        train_loader,
        val_loader,
        criterion,
        optimizer_resnet,
        scheduler_resnet,
        num_epochs=config.EPOCHS
    )
    
    # Save ResNet model
    torch.save(resnet_model.state_dict(), 'resnet_fake_detector.pth')
    
    # Initialize and train ensemble model
    print("Training ensemble model...")
    ensemble_model = EnsembleModel(efficientnet_model, resnet_model).to(config.DEVICE)
    
    # Freeze base models
    for param in efficientnet_model.parameters():
        param.requires_grad = False
    
    for param in resnet_model.parameters():
        param.requires_grad = False
    
    optimizer_ensemble = optim.Adam(ensemble_model.weight_layer.parameters(), lr=0.001)
    scheduler_ensemble = CosineAnnealingLR(optimizer_ensemble, T_max=10)
    
    ensemble_model = train_model(
        ensemble_model,
        train_loader,
        val_loader,
        criterion,
        optimizer_ensemble,
        scheduler_ensemble,
        num_epochs=10
    )
    
    # Save ensemble model
    torch.save(ensemble_model.state_dict(), config.ENSEMBLE_MODEL_PATH)
    
    # Evaluate models
    print("\nEvaluating EfficientNet model...")
    efficientnet_auc = evaluate_model(efficientnet_model, test_loader)
    
    print("\nEvaluating ResNet model...")
    resnet_auc = evaluate_model(resnet_model, test_loader)
    
    print("\nEvaluating Ensemble model...")
    ensemble_auc = evaluate_model(ensemble_model, test_loader)
    
    print(f"\nModel AUC Comparison:")
    print(f"EfficientNet AUC: {efficientnet_auc:.4f}")
    print(f"ResNet AUC: {resnet_auc:.4f}")
    print(f"Ensemble AUC: {ensemble_auc:.4f}")
    
    # Visualize attention maps
    print("\nVisualizing attention maps...")
    visualize_attention(efficientnet_model, test_loader)
    
    # Save the best model based on AUC
    best_model = None
    best_auc = 0
    
    if efficientnet_auc > best_auc:
        best_model = efficientnet_model
        best_auc = efficientnet_auc
    
    if resnet_auc > best_auc:
        best_model = resnet_model
        best_auc = resnet_auc
    
    if ensemble_auc > best_auc:
        best_model = ensemble_model
        best_auc = ensemble_auc
    
    torch.save(best_model.state_dict(), config.MODEL_PATH)
    print(f"Best model saved with AUC: {best_auc:.4f}")

if __name__ == "__main__":
    main()