import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Subset, WeightedRandomSampler
from torchvision import datasets, transforms, models
from PIL import Image, ImageFile
import os
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# Allow loading of truncated images
ImageFile.LOAD_TRUNCATED_IMAGES = True

# Define dataset paths
data_dir = r"/home/vu-lab03-pc40/dl/realandfake_split"
train_dir, val_dir, test_dir = [os.path.join(data_dir, x) for x in ["train", "val", "test"]]

# Function to remove corrupted images
def remove_corrupted_images(directory):
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with Image.open(file_path) as img:
                    img.verify()  # Check corruption
            except (OSError, Image.DecompressionBombError):
                print(f"Removing corrupted image: {file_path}")
                os.remove(file_path)  # Delete corrupted file

# Remove corrupted images before loading dataset
for folder in [train_dir, val_dir, test_dir]:
    remove_corrupted_images(folder)

# Define data augmentation
train_transform = transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(20),
    transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2, hue=0.1),
    transforms.RandomAffine(degrees=10, translate=(0.1, 0.1)),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

test_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

# Custom dataset loader to skip corrupted images
class CustomImageFolder(datasets.ImageFolder):
    def __getitem__(self, index):
        try:
            return super().__getitem__(index)
        except (OSError, Image.DecompressionBombError):
            print(f"Skipping corrupted image: {self.imgs[index][0]}")
            return self.__getitem__((index + 1) % len(self.imgs))  # Retry with next image

# Load dataset with transformations
full_dataset = CustomImageFolder(train_dir, transform=train_transform)
test_dataset = CustomImageFolder(test_dir, transform=test_transform)

# Get class counts and compute weights
class_counts = np.bincount(full_dataset.targets)
num_real, num_fake = class_counts[0], class_counts[1]
total_samples = num_real + num_fake

# Compute class weights
weight_real = total_samples / (2 * num_real)
weight_fake = total_samples / (2 * num_fake)
class_weights = torch.tensor([weight_real, weight_fake], dtype=torch.float)

# Stratified train-validation split
train_idx, val_idx = train_test_split(
    np.arange(len(full_dataset.targets)), test_size=0.2, stratify=full_dataset.targets, random_state=42
)

train_dataset, val_dataset = Subset(full_dataset, train_idx), Subset(full_dataset, val_idx)

# Create weighted sampler for handling class imbalance
samples_weight = np.array([weight_real if full_dataset.targets[idx] == 0 else weight_fake for idx in train_idx])
sampler = WeightedRandomSampler(torch.from_numpy(samples_weight), len(samples_weight))

# Create DataLoaders
train_loader = DataLoader(train_dataset, batch_size=32, sampler=sampler)
val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# Load EfficientNet model
model = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.IMAGENET1K_V1)

# Modify classifier for binary classification with dropout
num_ftrs = model.classifier[1].in_features
model.classifier = nn.Sequential(
    nn.Linear(num_ftrs, 256),
    nn.ReLU(),
    nn.Dropout(0.5),  # Increased dropout
    nn.Linear(256, 128),
    nn.ReLU(),
    nn.Dropout(0.4),  # Extra dropout layer
    nn.Linear(128, 1)
)

# Move model to GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")
model = model.to(device)

# Define loss function and optimizer
criterion = nn.BCEWithLogitsLoss(pos_weight=class_weights[1].to(device))
optimizer = optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-4)

# Training function
def train_model(model, train_loader, val_loader, criterion, optimizer, epochs=30):
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        train_loader_tqdm = tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs}", leave=False)

        for images, labels in train_loader_tqdm:
            images, labels = images.to(device), labels.float().unsqueeze(1).to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
            train_loader_tqdm.set_postfix(loss=running_loss / len(train_loader))

        # Validation loss
        val_loss = 0.0
        model.eval()
        with torch.no_grad():
            for images, labels in val_loader:
                images, labels = images.to(device), labels.float().unsqueeze(1).to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                val_loss += loss.item()

        print(f"Epoch {epoch+1}/{epochs}, Train Loss: {running_loss/len(train_loader):.4f}, Val Loss: {val_loss/len(val_loader):.4f}")

# Train the model
train_model(model, train_loader, val_loader, criterion, optimizer, epochs=20)

# Save the trained model
torch.save(model.state_dict(), "deepfake_model1.pth")
print("Model saved as deepfake_model1.pth")

# Evaluation function
def evaluate_model(model, test_loader):
    model.eval()
    all_preds, all_labels = [], []

    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            predicted = (outputs > 0.5).float().squeeze()
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    print(classification_report(all_labels, all_preds, target_names=['Real', 'Fake']))

# Evaluate model performance
evaluate_model(model, test_loader)